import { createStore } from 'redux';
import appState from '../redux';

const store = createStore(appState);
export default store;
